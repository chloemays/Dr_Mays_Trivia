from .utils import register_event_handlers


__all__ = ["register_event_handlers"]
