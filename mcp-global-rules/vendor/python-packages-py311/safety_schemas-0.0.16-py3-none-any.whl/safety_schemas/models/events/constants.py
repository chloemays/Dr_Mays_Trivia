SAFETY_NAMESPACE = "safetycli"
PRODUCT_CLI = "cli"
GITHUB = "github"
PYPI = "pypi"
DOCKER = "docker"
ACTION = "action"
APP = "app"

CLI_SOURCE = f"urn:{SAFETY_NAMESPACE}:{PRODUCT_CLI}"
