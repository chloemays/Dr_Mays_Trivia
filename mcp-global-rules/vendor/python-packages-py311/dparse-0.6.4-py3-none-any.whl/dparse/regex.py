HASH_REGEX = r"--hash[=| ]\w+:\w+"
