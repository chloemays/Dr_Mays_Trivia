"""Top-level package for Dependency Parser."""

__author__ = """Jannis Gebauer"""
__email__ = 'support@pyup.io'
__version__ = '0.6.3'

from .parser import parse  # noqa
